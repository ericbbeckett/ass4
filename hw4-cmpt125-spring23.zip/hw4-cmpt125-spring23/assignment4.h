#ifndef ASSIGNMENT4_H
#define ASSIGNMENT4_H

#include <stdbool.h>

#include "lib/stack_int.h"

/* Question 1 */


// the function gets an array of strings of length n
// and sorts the strings in the array.
// Two strings are compared as follows:
// - Compute the sum of all digits in the string.
// - The string with the lower sum should appear first in the sorted array
// - If two strings have the same sum, the two strings can be in any order
void sort_strings(const char* A[], int n);

/* Question 2 */

// The function gets an array of length n of ints,
// and applies the selection sort algorithm on the array.
// The function returns the array of ints of length n, where
// output[i] is the index where the i’th smallest number was found
int* selection_sort(int* A, int n);

/* Question 3 */

// the function gets an array of length n of objects of given size and a compare function
// The function applies insertion sort on the array using the compare function
// if compare (a,b)<0, then a must come before b in the sorted array
// if compare (a,b)>0, then a must come after b in the sorted array
void gen_insertion_sort(void* array, int n, size_t size, int (*compare)(const void*, const void*));

/* Question 4 */

// returns the size of the stack
int stack_size(stack_int_t* s);

// counts the number of x’s in the stack with pred(x)=true
int stack_count(stack_int_t* s, bool(*pred)(int));

// reverses theorder of the elements in the stack
// For example, suppose we push 10, then 20, and then 30.
// Then we apply reverse
// pop() will return 10
// Then we apply reverse again
// pop() will return 30
// pop() will return 20
// now the stack is empty
void stack_reverse(stack_int_t* s);  

#endif
