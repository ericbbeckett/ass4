#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


#include "lib/stack_int.h"
#include "assignment4.h"

/* Question 1 */

void test_q1_1() {
  const char* A[] = {"hello!1", "World", "6a", "2", "12345678"};
  sort_strings(A, 5);
  const char* correct_ans[] = {"World", "hello!1",  "2", "6a", "12345678"};

  bool flag_ok = true;
  for (int i = 0; i < 5; i++) {
    if (strcmp(A[i], correct_ans[i]) != 0) {
      flag_ok = false;
      break;
    }
  }
  if (flag_ok)
    printf("Q1-1 ok\n");
  else
    printf("Q1-1 ERROR\n");
}


void test_q1_2() {
  const char* A[] = {"W00x00", "ab1", "6_@7123h", "80", "b012", "b"};
  sort_strings(A, 6);
  const char* correct_ans1[] = {"W00x00", "b", "ab1", "b012", "80", "6_@7123h"};
  const char* correct_ans2[] = {"b", "W00x00", "ab1", "b012", "80", "6_@7123h"};

  bool flag1_ok = true;
  for (int i = 0; i < 6; i++) {
    if (strcmp(A[i], correct_ans1[i]) != 0) {
      flag1_ok = false;
      break;
    }
  }

  bool flag2_ok = true;
  for (int i = 0; i < 6; i++) {
    if (strcmp(A[i], correct_ans2[i]) != 0) {
      flag2_ok = false;
      break;
    }
  }
  if (flag1_ok || flag2_ok)
    printf("Q1-2 ok\n");
  else
    printf("Q1-2 ERROR\n");
}

/* Question 2 */

bool equal_arrays(int* a1, int* a2, int n) {
  for (size_t i = 0; i < n; i++)
    if (a1[i] != a2[i])
      return false;
  return true;
}

void test_q2_1()  {
  int ar[] = {40,30,60,10,20,50};
  int* trace =  selection_sort(ar, 6);

  int correct_ans[] = {10,20,30,40,50,60};
  int correct_trace[] = {3,4,4,3,5,5};

  bool flag_ok;
  if (!trace) {
    flag_ok = false;
  }
  else {
    flag_ok = (equal_arrays(ar, correct_ans, 6) && equal_arrays(trace, correct_trace, 6));
    free(trace);
  }

  if (flag_ok)
    printf("Q2-1 ok\n");
  else
    printf("Q2-1 ERROR\n");
}

#define LEN 100
void test_q2_2()  {
  int ar[LEN];
  for (int i = 0; i < LEN; i++)
    ar[i] = LEN-i;

  int* trace =  selection_sort(ar, LEN);

  int correct_ans[LEN];
  for (int i = 0; i < LEN; i++)
    correct_ans[i] = i+1;

  int correct_trace[LEN];
  for (int i = 0; i < LEN/2; i++)
    correct_trace[i] = correct_trace[LEN-1-i] = LEN-1-i;


  bool flag_ok;
  if (!trace) {
    flag_ok = false;
  }
  else {
    flag_ok = (equal_arrays(ar, correct_ans, LEN) && equal_arrays(trace, correct_trace, LEN));
    free(trace);
  }

  if (flag_ok)
    printf("Q2-2 ok\n");
  else
    printf("Q2-2 ERROR\n");
}

/* Question 3 */

int cmpr_ints_decr(const void* a, const void* b) {
  return *(const int*)b - *(const int*)a;
}

void test_q3_1() {

  int n = 6;
  int ar[6] = {7,3,5,1,11,9};
  
  // cmpr_ints_decr sorts the array in reverse order
  gen_insertion_sort(ar, n, sizeof(int), cmpr_ints_decr);
  
  int correct_ans[] = {11,9,7,5,3,1};
  
  if (equal_arrays(ar, correct_ans, n))
    printf("Q3-1 ok\n");
  else
    printf("Q3-1 ERROR\n");
}

typedef struct {
  int x;
  int y;
} point2d;


// used for test test_q3_2
// sort points by the x-coordinate
// and if the x-coordinates are equal, sort by the y-coordinate
int cmpr_points_L2(const void* a, const void* b) {
  point2d pt1 = *(const point2d*) a;
  point2d pt2 = *(const point2d*) b;
  if (pt1.x != pt2.x)
    return (pt1.x-pt2.x);
  else // pt1.x == pt2.x
    return (pt1.y-pt2.y);
}

void test_q3_2() {
  int n = 5;
  point2d ar[5] = {{2,0}, {0,-6}, {5,3}, {3,4}, {3,0}};

  gen_insertion_sort(ar, n, sizeof(point2d), cmpr_points_L2);
  
  point2d correct_ans[5] = {{0,-6}, {2,0}, {3,0}, {3,4}, {5,3}};

  bool okFlag = true;
  for (int i=0;i<n;i++) 
    if (ar[i].x != correct_ans[i].x || ar[i].y != correct_ans[i].y) {
      okFlag = false;
      break;
    }

  if (okFlag)
    printf("Q3-2 ok\n");
  else
    printf("Q3-2 ERROR\n");
}


/* Question 4 */

void test_q4_size() {

  stack_int_t* s = stack_create();
  int i=0;

  for (i=0;i<100;i++) stack_push(s, i);
  int size1 = stack_size(s);

  for (i=0;i<10;i++) stack_pop(s);
  int size2 = stack_size(s);

  for (i=0;i<60;i++) stack_push(s, 999);
  int size3 = stack_size(s);

  stack_free(s);

  if (size1==100 && size2==90 && size3==150)
    printf("Q1-size ok\n");
  else
    printf("Q1-size ERROR\n");
} 

bool is_odd(int x) {return 1==x%2;}
bool is_zero(int x) {return x==0;}

void test_q4_count() {

  stack_int_t* s = stack_create();
  int i=0;

  for (i=0;i<100;i++) stack_push(s, i);

  int ans1 = stack_count(s, is_odd);
  int ans2 = stack_count(s, is_odd);
  int ans3 = stack_count(s, is_zero);

  for (i=0;i<10;i++) stack_push(s,999);
  int ans4 = stack_count(s, is_odd);
  int ans5 = stack_count(s, is_zero);

  for (i=0;i<50;i++) stack_pop(s);
  int ans6 = stack_count(s, is_odd);
  int ans7 = stack_count(s, is_zero);
  int size = stack_size(s);

//  printf("%d %d %d %d  %d %d %d %d\n", ans1, ans2, ans3, ans4, ans5, ans6, ans7, size);
  stack_free(s);

  if (ans1==50 && ans2==50 && ans3==1
        && ans4==60 && ans5==1
        && ans6==30 && ans7==1
        && size==60)
    printf("Q3-count ok\n");
  else
    printf("Q3-count ERROR\n");
}

void  test_q4_reverse() {

  stack_int_t* s = stack_create();
  int i=0;

  for (i=0;i<5;i++) stack_push(s, i);
  // [ 0 1 2 3 4 ] <--
  stack_reverse(s);
  for (i=6;i<10;i++) stack_push(s, i);
  // [ 4 3 2 1 0 6 7 8 9 ] <--

  if (stack_pop(s)!=9) {
    printf("Q4-reverse-1 ERROR\n");
    return;
  }
  stack_reverse(s);
  // [ 4 3 2 1 0 6 7 8 ] <--

  if (stack_pop(s)!=4) {
    printf("Q4-reverse-2 ERROR\n");
    return;
  }
  // [ 8 7 6 0 1 2 3 ] <--

  stack_reverse(s);
  for (int i = 8; i >= 6; i--)
    if (stack_pop(s)!=i) {
      printf("Q4-reverse-3 ERROR\n");
      return;
  }
  // [ 3 2 1 0 ] <--

  for (int i = 0; i <= 3; i++)
    if (stack_pop(s)!=i) {
      printf("Q4-reverse-4 ERROR\n");
      return;
  }
  // [] <--

  stack_reverse(s);
  
  if (stack_is_empty(s))
    printf("Q4-reverse ok\n");
  else
    printf("Q4-reverse ERROR\n");
}



// when testing your code, it may be convenient 
// to comment out some of the test cases
// and focus only on the one you are working on right now.
// Also, you are encouraged to add more test casess
int main()  {

  
  test_q1_1();
  test_q1_2();
  test_q2_1();
  test_q2_2();
  test_q3_1();
  test_q3_2();

  test_q4_size();
  test_q4_count();
  test_q4_reverse();

  return 0;
}