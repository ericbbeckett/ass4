#ifndef STACK_INT_H
#define STACK_INT_H


#define INIT_CAPACITY 10


// stack of bounded capacity 
typedef struct {
    int* ar;
    int capacity;
    int head;
} stack_int_t; 

// creates a new stack
stack_int_t* stack_create();

// pushes a given item to the stack
// Returns item if the operation is successful
int stack_push(stack_int_t* s, int item);

// pops the top element from the stack
// Pre condition: stack is not empty
int stack_pop(stack_int_t* s);

// returns 1 if the stack is empty, and returns 0 otherwise
int stack_is_empty(stack_int_t* s);

// returns 1 if the stack is empty, and returns 0 otherwise
void stack_free(stack_int_t* s);

#endif