#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "assignment4.h"

// helper function that sums all digits in string
int sum_digit(const char* str)
{
  int sum = 0;
  for(const char* p = str; *p != '\0'; ++p)
  {
      if(*p >= '0' && *p <= '9')
      {
        sum += *p - '0';
      }
  }
  return sum;
}

// helper function that swaps values pointed to
void swap_strings(const char** a, const char** b)
{
  const char* tmp = *a;
  *a = *b;
  *b = tmp;
}


void sort_strings(const char* A[], int n) {
  for(int i = 0; i < n - 1; ++i)
  {
    for(int j = 0; j < n - 1 - i; ++j)
    {
      // calculate the sum of digits for the current and next string
      int sum_j = sum_digit(A[j]);
      int sum_j_plus = sum_digit(A[j+1]);

      
      if(sum_j > sum_j_plus) // if the sum of the current string is greater than the sum of the next string...
      {
        swap_strings(&A[j], &A[j+1]);  // swap the current and next strings
      }
    }
  }
}


/* Question 2 */

int* selection_sort(int* A, int n) {
  int i, j, min_idex, temp;
  int* return_array = malloc(sizeof(int)*n);

  for(i = 0; i < n; i++) 
  {
    min_idex = i; // set the current index as the minimum index

    for(j = i + 1; j < n; j++) // search for the minimum element from the i+1th position to the end of the array
    {
      if(A[j] < A[min_idex]) // if smaller element is found, update the minimum index
      {
        min_idex = j;
      }
    }

    // swap the minimum element with the current element at index i
    temp = A[min_idex];
    A[min_idex] = A[i];
    A[i] = temp;

    return_array[i] = min_idex;
  }

  return return_array;
}


/* Question 3 */

void gen_insertion_sort(void* array, int n, size_t size, int (*compare)(const void*, const void*)) {
  for(int i = 1; i < n; i++) 
  {
    // create a copy of the current element to be sorted
    void* curr_el = malloc(size);
    memcpy(curr_el, array + i * size, size);
    
    int j = i - 1;

    // while the current index is greater than or equal to 0 
    // and the element at the previous index is greater than the current element
    while(j >= 0 && compare(array + j * size, curr_el) > 0) 
    {
      memcpy(array + (j + 1) * size, array + j * size, size); // move the element at the previous index to the next index
      j--;
    }

    memcpy(array + (j + 1) * size, curr_el, size); // insert the current element at its correct position in the array
    free(curr_el);
  }
}



/* Question 4 */

int stack_size(stack_int_t* s) {
  int size = s->head;  // get the current size of the stack
  stack_int_t* temp = stack_create();  // create a temporary stack

  while(!stack_is_empty(s)) 
  {
    stack_push(temp, stack_pop(s));  // pop elements off the original stack and push them onto the temporary stack
  }
  while(!stack_is_empty(temp)) 
  {
    stack_push(s, stack_pop(temp));  // pop elements off the temporary stack and push them back onto the original stack
  }

  stack_free(temp);  // free the memory used by the temporary stack
  return size;  
}


int stack_count(stack_int_t* s, bool(*pred)(int)) {
  int count = 0;
  stack_int_t* temp = stack_create();  // create a temporary stack

  while(!stack_is_empty(s)) 
  {
    int val = stack_pop(s);
    if(pred(val)) 
    {
      count++;
    }
    stack_push(temp, val);  // push the item onto the temporary stack
  }

  while(!stack_is_empty(temp)) 
  {
    stack_push(s, stack_pop(temp));  // pop elements off the temporary stack and push them back onto the original stack
  }

  stack_free(temp);  // free the memory used by the temporary stack
  return count;
}


void stack_reverse(stack_int_t* s) {
  int size = stack_size(s);
  int* arr = malloc(sizeof(int)*size);

  // iterate through the stack from the top, popping each element and adding it to the array in reverse order
  for(int i = 0; i < size; i++) 
  {
    arr[i] = stack_pop(s); 
  }

  // iterate through the array in its new reversed order and push each element back onto the stack
  for(int i = 0; i < size; i++) 
  {
    stack_push(s, arr[i]);
  }

  free(arr);
}



